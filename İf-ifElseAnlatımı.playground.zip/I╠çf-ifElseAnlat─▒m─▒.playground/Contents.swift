import UIKit

var yas = 19
var isim = "Ahmet"

if yas >= 18 {
    print ("Reşitsiniz")
} else {
    print ("Reşit değilsiniz")
}




var isim1 = "Arda"
if isim1 == "Ahmet" {
    print ("Doğru kişi")
}
else if isim1 == "Mehmet" {
    print ("Doğru kişi")
} else {
    print ("Yanlış kişi")
}


var ka = "admin"
var s = 123456

if ka == "admin" && s == 123456 {
    print ("doğru giriş")
} else {
    print ("yanlış giriş")
}


var sonuc = 11

if sonuc == 9 || sonuc == 10 {
    print ("doğru kullanım")
} else {
    print ("yanlış kullanım")
}
